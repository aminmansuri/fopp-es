from tortuga_nitro import *


def main():
    ventana = Screen()
    tortuga_nitro = TortugaNitro()
    #configuraciones básicas de la ventan
    ventana.bgcolor("white")
    ventana.title("Segunda Clase")
    ventana.setup(400, 300)
    #este es nuestro método main al cual iremos llamando lo métodos
    # para ser ejecutados
    #agregar métodos a continuación...
    # .
    # .
    # .
    # indica a la ventana que se mantenga abierta hasta que nosostros
    # decidamos cerrarla. Esto debe ir siempre al final del método main
    ventana.mainloop()

if __name__ == "__main__":
    main()

