from turtle import *
import math
import random

class TortugaNitro(Turtle):

    def __init__(self):
        Turtle.__init__(self)
        self.shape('turtle')
        self.color('green')
        self.speed(1)
        self.penup()
        self.goto(100, 0)
        self.pendown()

    def dibujar_triangulo(self,lado):
        pass

    def dibujar_triangulo_sierpinski(self, ancho, profundidad):
        pass


    def dibujar_margarita(self):
        pass


    def dibujar_sol(self):
        pass

    def dibujar_espiral(self, tam_linea):
        pass
