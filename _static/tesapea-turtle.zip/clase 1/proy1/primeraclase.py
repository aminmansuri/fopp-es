# -*- coding: utf-8 -*-
#!/usr/bin/env python

##############################################################################
####### importamos las librerías que utilizaremos en la clase ################
##############################################################################

from turtle import *
import math #puedes o no utilizarla


##############################################################################
###################### Definición de Métodos   ###############################
##############################################################################


def triangulo_equilatero(dibujador):
    # Utilizaremos esté metodo para dibujar un triangulo equilatero con nuestra
    # tortuga
    # TO-DO agregar logica ...
    pass


def cuadrado(dibujador):
    # dibujaremos un cuadrado con este método
    # TO-DO agregar logica ...
    pass


def rectangulo(dibujador):
    # dibujaremos un rectangulo con este método
    # TO-DO agregar logica ...
    pass


def tres_cuadrados(dibujador):
    # dibujaremos un 3 cuadrados unidos en una arista con este método
    # TO-DO agregar logica ...
    pass


def rombo(dibujador):
    # dibujaremos un rombo
    # TO-DO agregar logica ...
    pass

def triangulo_equilatero_generalizado(dibujador, tam_lado):
    # Utilizaremos esté metodo para dibujar un triangulo equilatero con nuestra
    # tortuga
    # TO-DO agregar logica ...
    pass


def cuadrado_generalizado(dibujador, tam_lado = 100):
    # dibujaremos un cuadrado con este método
    # TO-DO agregar logica ...
    pass


def rectangulo_generalizado(dibujador, tam_ancho, tam_largo):
    # dibujaremos un rectangulo con este método
    # TO-DO agregar logica ...
    pass


def tres_cuadrados_generalizados(dibujador,tam_lado):
    # dibujaremos un 3 cuadrados unidos en una arista con este método
    # TO-DO agregar logica ...
    pass


def rombo_generalizado(dibujador,tam_lado):
    # dibujaremos un rombo
    # TO-DO agregar logica ...
    pass
##############################################################################
###################### Definición del main     ###############################
##############################################################################


def main():
    ##############################################################################
    ########## DEFINICIÓN DE VARIABLES Y/O MÉTODOS ###############################
    ##############################################################################
    # creamos nuestra ventana donde mostrar nuestra tortuga
    ventana = Screen()
    # creamos nuestro objeto turtuga
    tortuga = Turtle()
    ##############################################################################
    ########## CONFIGURACIÓNES DE VENTANA ########################################
    ##############################################################################
    #configuraciones básicas de la ventana
    ventana.bgcolor("white")
    ventana.title("Primera Clase")
    ventana.setup(800, 600)
    ##############################################################################
    ########## INVOCACIONES DE MÉTODOS ###########################################
    ##############################################################################
    #este es nuestro método main al cual iremos llamando lo métodos
    # para ser ejecutados
    #agregar métodos a continuación...
    # .
    # .
    # .
    # indica a la ventana que se mantenga abierta hasta que nosostros
    # decidamos cerrarla. Esto debe ir siempre al final del método main
    ventana.mainloop()

if __name__ == "__main__":
    main()

